﻿namespace RestFulClient
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_URL = new System.Windows.Forms.TextBox();
            this.txt_response = new System.Windows.Forms.TextBox();
            this.btn_send = new System.Windows.Forms.Button();
            this.lbl_URL = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_URL
            // 
            this.txt_URL.Location = new System.Drawing.Point(101, 14);
            this.txt_URL.Name = "txt_URL";
            this.txt_URL.Size = new System.Drawing.Size(428, 20);
            this.txt_URL.TabIndex = 0;
            // 
            // txt_response
            // 
            this.txt_response.Location = new System.Drawing.Point(101, 40);
            this.txt_response.Multiline = true;
            this.txt_response.Name = "txt_response";
            this.txt_response.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_response.Size = new System.Drawing.Size(511, 191);
            this.txt_response.TabIndex = 1;
            // 
            // btn_send
            // 
            this.btn_send.Location = new System.Drawing.Point(535, 12);
            this.btn_send.Name = "btn_send";
            this.btn_send.Size = new System.Drawing.Size(77, 23);
            this.btn_send.TabIndex = 2;
            this.btn_send.Text = "Send";
            this.btn_send.UseVisualStyleBackColor = true;
            this.btn_send.Click += new System.EventHandler(this.btn_send_Click);
            // 
            // lbl_URL
            // 
            this.lbl_URL.Location = new System.Drawing.Point(12, 12);
            this.lbl_URL.Name = "lbl_URL";
            this.lbl_URL.Size = new System.Drawing.Size(83, 22);
            this.lbl_URL.TabIndex = 3;
            this.lbl_URL.Text = "Requiest URL:";
            this.lbl_URL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 191);
            this.label1.TabIndex = 4;
            this.label1.Text = "Response:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 241);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_URL);
            this.Controls.Add(this.btn_send);
            this.Controls.Add(this.txt_response);
            this.Controls.Add(this.txt_URL);
            this.Name = "Form_Main";
            this.Text = "RestFul Client";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_URL;
        private System.Windows.Forms.TextBox txt_response;
        private System.Windows.Forms.Button btn_send;
        private System.Windows.Forms.Label lbl_URL;
        private System.Windows.Forms.Label label1;
    }
}

