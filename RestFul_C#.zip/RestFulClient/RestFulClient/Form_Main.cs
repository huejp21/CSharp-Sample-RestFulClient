﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestFulClient
{
    public partial class Form_Main : Form
    {
        public Form_Main()
        {
            InitializeComponent();
        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            RestFulClient cl = new RestFulClient();
            cl.endPoint = txt_URL.Text;
            if (txt_URL.Text.Trim() == "")
            {
                cl.endPoint = "http://dry-cliffs-19849.herokuapp.com/users.json";
            }

            DebugOutput("Rest Client Created");

            string response = string.Empty;
            response = cl.makeRequest();

            DebugOutput(response);
        }

        private void DebugOutput(string text)
        {
            try
            {
                System.Diagnostics.Debug.Write(text + Environment.NewLine);
                txt_response.Text = txt_response.Text + text + Environment.NewLine;
                txt_response.SelectionStart = txt_response.TextLength;
                txt_response.ScrollToCaret();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.Message, ToString() + Environment.NewLine);
            }
        }
    }
}
