﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.IO;

namespace RestFulClient
{
    public enum httpVerb
    {
        GET,
        POST,
        PUT,
        DELETE,
    }

    class RestFulClient
    {
        public string endPoint { set; get; }
        public httpVerb httpMethod { set; get; }

        public RestFulClient()
        {
            endPoint = string.Empty;
            httpMethod = httpVerb.GET;
        }

        public string makeRequest()
        {
            string reqVal = string.Empty;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(endPoint);
            request.Method = httpMethod.ToString();
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApplicationException("error code: " + response.StatusCode.ToString());
                }
                using (Stream responseStream = response.GetResponseStream())
                {
                    if (responseStream != null)
                    {
                        using (StreamReader reader = new StreamReader(responseStream))
                        {
                            reqVal = reader.ReadToEnd();
                        }
                    }
                }
            }
            return reqVal;
        }
    }
}
